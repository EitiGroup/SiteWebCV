import BasicContact from './BasicContact'
import SocialContact from './SocialContact'

export default {
  Basic: BasicContact,
  Social: SocialContact,
}
