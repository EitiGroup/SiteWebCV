export default `
@font-face {
  font-family: 'SF UI Text';
  src: url('/fonts/SF-UI-Text-Regular.woff') format('woff');
  font-display: swap;
  font-style: normal;
  font-weight: normal;
}

@font-face {
  font-family: 'SF UI Text';
  src: url('/fonts/SF-UI-Text-Bold.woff') format('woff');
  font-display: swap;
  font-style: normal;
  font-weight: bold;
}

@font-face {
  font-family: 'SF UI Text';
  src: url('/fonts/SF-UI-Text-RegularItalic.woff') format('woff');
  font-display: swap;
  font-style: italic;
  font-weight: normal;
}

@font-face {
  font-family: 'SF UI Text';
  src: url('/fonts/SF-UI-Text-Light.woff') format('woff');
  font-display: swap;
  font-style: normal;
  font-weight: 300;
}
`
