<template>
  <WorkLayout
    name="John Deere"
    :slideCount="0"
    loc="25,000"
    period="Nov 2018 – Jan 2019"
    tech="JavaScript, React, Sass, Redux"
  >
    <p>
      Coming soon.
    </p>
  </WorkLayout>
</template>
