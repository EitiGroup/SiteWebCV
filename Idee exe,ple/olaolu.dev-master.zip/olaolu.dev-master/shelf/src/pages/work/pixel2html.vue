<template>
  <WorkLayout
    name="Pixel2HTML"
    :slideCount="0"
    loc="25,000"
    period="Feb – Mar 2019"
    tech="JavaScript, Gatsby, Styled Components"
  >
    <p>Coming soon.</p>
  </WorkLayout>
</template>
