<template>
  <WorkLayout
    name="Dignisia"
    :slideCount="0"
    loc="6,000"
    period="Oct – Nov 2018"
    tech="JavaScript, Next.js, Sass"
  >
    <p>Coming soon.</p>
  </WorkLayout>
</template>
