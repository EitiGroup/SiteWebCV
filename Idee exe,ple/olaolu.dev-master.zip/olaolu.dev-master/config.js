module.exports = {
  hireable: false,
  SHELF_PORT: 8081,
  LANDING_PORT: 8080,
  ANALYTICS_ID: 'UA-152557312-1',
  excludeFromShelfDir: ['work', 'resume', 'work-images'],
}
