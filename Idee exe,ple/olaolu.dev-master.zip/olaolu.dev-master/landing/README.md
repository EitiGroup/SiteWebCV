## Homepage for olaolu.dev

This app is based off of [vue-cli](https://cli.vuejs.org).

- For development, run `yarn serve:landing`
- For production, run `yarn build:landing`

## License

Copyright (c) 2019-present Olaolu Olawuyi. All rights reserved.

**The code, design and articles in this repository are intellectual property of
the individual mentioned above (unless otherwise stated) and as such CANNOT be
copied, modified, sublicensed or redistributed without permission from the
author.**
